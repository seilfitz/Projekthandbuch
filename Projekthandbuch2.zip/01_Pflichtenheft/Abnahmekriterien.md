# Abnahmekriterien

> Platzhalter
